/**
Creates a team member which is assigned to a team. has a name and starting date as data members and can be initialized by passing these values 
into the constructor. The date however, must be in the form of a Date object. We also have a getStartDate() method to retrieve the date of the
team member in scope. The equals method will compare two team members and test to see if they are equal.
@author  Mark and Jeremy Barkalow
*/
public class TeamMember 
{
   private String name;
   private Date   startDate;
   
   /**
   constructor for TeamMember class. simply just creates a TeamMember object by initializing data members
   based on parameters.
   @param nm this parameter represents the name of the team member about to be created.
   @param date this parameter is a Date object which represents the date that the team member started on the team. 
   */
   public TeamMember(String nm, Date date)
   {
       name = nm;
	   startDate = date;
   }
   
   /**
   getStartDate() simply gets the startdate of the TeamMember object in scope.
   @return returns a date object which represents the start date of the TeamMember in scope.
    */
   public Date getStartDate()
   {
      return startDate;
   }
   
   /**
   this method tests whether two TeamMember objects are equal to one another by
   testing whether their data members are equal or not. In this case we would be testing whether their name and Date is the same.
   We have to call instanceof to check whether the passed object is a TeamMember object because comparing any other object would be pointless.
   @param obj this is the object being passed in that needs to be compared. We cast this to TeamMember once it is verified with that class.
   @return we return a boolean indicating whether the two TeamMembers are equal or not.
   */
   public boolean equals(Object obj)
   {
       if(!(obj instanceof TeamMember))// here we test to see if the obj parameter is of type TeamMember
           return false;
       TeamMember memberToCompare = (TeamMember)obj;// if obj is of type TeamMember, we cast it to that so we can access its data members.
	   if((name.equals(memberToCompare.name)) && (startDate.equals(memberToCompare.startDate)))
	   {
		   return true;
	   }
	   else
	   {
		   return false;
	   }
      //name and startDate must be the same
   }  
   
   /**
   for our toString() method we just simply grab the name and startDate of the TeamMember
   @return we return the name and startDate so it can be printed to console.
   */
   public String toString()
   {
	   return(name + " " + startDate);
	   
       //name + " " + startDate;
   }

   public static void main(String [] args)
   {
      Date jeremy_date = new Date("9/10/1998");
      TeamMember member1 = new TeamMember("jeremy", jeremy_date);
      System.out.println(member1);
      
      System.out.println(member1.getStartDate());
      
      TeamMember member2 = new TeamMember("jeremy", jeremy_date);
      System.out.println(member1.equals(member2));
       
      Date mark_date = new Date("9/11/1998");
      TeamMember mark = new TeamMember("mark", mark_date);
      System.out.println(member2.equals(mark));
   }
}