/**
The Team class is responsible for maintaining an array of TeamMembers as well as adding and removing TeamMembers.
The TeamMembers are held in an array which increases in size when the GROW_SIZE is reached in the array. The methods
that are public are used by ProjectManager which deals with user input and handling requests. This class is simply
carrying out those requests. This class also has two private methods which are used in the other methods.
@author  Mark and Jeremy Barkalow
*/
public class Team 
{
   private final int NOT_FOUND = -1;
   private final int GROW_SIZE = 4;
   private TeamMember [] team;
   private int numMembers;
   
   /**
   This is just the default constructor to make a Team object. It initializes the team instance variable and sets the 
   number of members to 0.
   */
   public Team()
   {
	   team = new TeamMember[GROW_SIZE];
	   numMembers = 0;
   }
   
   /**
   The find method just iterates through the array of TeamMembers until it finds the desired TeamMember. It performs
   the comparison using the equals method from the TeamMember class.
   @param m This references the TeamMember object to search for.
   @return the position of the TeamMember in the array or NOT_FOUND if the TeamMember does not exist.
   */
   private int find(TeamMember m)
   {
       for(int i = 0; i < numMembers; i++)
	   {
		   if((team[i].equals(m) == true))
		   {
			   return i;
		   }
	   }
	   return NOT_FOUND;
   }
   
   /**
   The grow method is called when size of the array of TeamMembers needs to be increased.
   This is done by creating a new array and iterating through the old one and adding those
   TeamMembers to the new one then setting the team instance variable to the new array.
   */
   private void grow()
   {
       int newSize = numMembers + GROW_SIZE;
	   TeamMember[] newTeam = new TeamMember[newSize];
	   for(int i = 0; i < numMembers; i++)
	   {
		   newTeam[i] = team[i];
	   }
	   team = newTeam;
	   
   }
   /**
   the isEmpty method is called by ProjectManager to check if the Team is empty before it prints
   the list of TeamMembers.
   @return true if there are no TeamMembers, false if there is at least 1 TeamMember.
   */
   public boolean isEmpty()
   {
       if(numMembers == 0)
           return true;
       else
           return false;
   }
   /**
   The add method is called by ProjectManager to add a new TeamMember to the Team.
   The method first checks to see if the size of the array needs to be increased. If not,
   then the TeamMember is added to the array. If the size needs to be increased, the grow
   method is called.
   @param m References the TeamMember object to be added to the Team.
   */
   public void add(TeamMember m)
   {
       if(numMembers % 4 == 0)
           grow();
		team[numMembers] = m;
		numMembers++;
   }
   /**
   The remove method is called by ProjectManager when it needs to remove a TeamMember.
   It works by first calling the find method to see if the TeamMember exists. If the TeamMember
   does exist, the last TeamMember in the array is placed into the location of the TeamMember
   being removed. Then, the size of the array is reduced by one.
   @param m references the TeamMember object to be removed from the array.
   @return False if the TeamMember does not exist. True if the TeamMember was removed successfully.
   */
   public boolean remove(TeamMember m)
   {
       int indexRemove = find(m);
	   if(indexRemove == -1)
		   return false;
	   team[indexRemove] = team[numMembers-1];
	   team[numMembers-1] = null;
	   numMembers--;
	   return true;
	   
   } 
   
   /**
   The contains method is called by ProjectManager to see if a TeamMember already exists in the Team.
   This method works by calling the find method.
   @param m References the TeamMember object.
   @return true if the TeamMember exists in the Team. False if the TeamMember does not exist in the Team.
   */
   public boolean contains(TeamMember m)
   {
      if(find(m) > NOT_FOUND)
          return true;
      else
          return false;
   } 
   /**
   The print method simply iterates through the array of TeamMembers and prints out the name and start date
   of each TeamMember. The toString method in TeamMember is called when printing the objects.
   */
   public void print()
   {
	   for(int i = 0; i < numMembers; i++)
	   {
		   System.out.println(team[i]);
		   
	   }
   } 
}
