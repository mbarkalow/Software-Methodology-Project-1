import java.util.StringTokenizer;

/**
 This class is used to create a date object so that a start date can be assigned to each team member on the team. 
 A date is in mm/dd/yyyy format and a Date can be created by passing this a string in that format to the constructor.
 There is also an isValid() method which tests to make sure the inputted date is indeed a valid date. the testLeapYear method
 is a helper function for testing validity. In addition, there is an equals() method which can be used to test whether two Date 
 objects are equal to one another.
 @author  Mark and Jeremy Barkalow
 */


public class Date 
{
   private int  day;
   private int  month;
   private int  year;
   
   /**
    constructor for the Date class, takes a string as a parameter which is in "mm/dd/yyyy" format and initializes this data 
    to the data members for the Date class. We grab these values using a string tokenizer and setting the "/" as the delimiter 
    to separate the values.
    @param d takes in a string in "mm/dd/yyyy" format and parses these values out.
    */
   public Date(String d)
   {
	  StringTokenizer parser = new StringTokenizer(d,"/");// we set a string tokenizer to parse through the string and set the delimiter to a "/" to separate our values.
	  int variableCounter = 0;
	  while(parser.hasMoreTokens())
	  {
	      try// using this try catch block to catch any non-integer inputs for starting dates.
	      {
	          if(variableCounter == 0)
                  month = Integer.parseInt(parser.nextToken());
              else if(variableCounter == 1)
                  day = Integer.parseInt(parser.nextToken());
              else if(variableCounter == 2)
                  year = Integer.parseInt(parser.nextToken());
              variableCounter++;
	      }
	      catch(NumberFormatException ex)
	      {

	      }
	          
	      
	  }
	  
      //use StringTokenizer to parse the String and create a Date object     
   }
   /**
    takes in a Date parameter and takes the values from this Date object and initializes the current data members in scope
    @param d Date object passed to function
    */
   public Date(Date d)
   {
       day = d.day;
       month = d.month;
       year = d.year;
       //this is a constructor
   }
   
   /**
    This function tests if the year given is a leap year by doing some basic calculations that was
    provided to us in the project description. The modulus operator was definitely 
    useful for this function
    @param year integer value representing what year is being tested for a leap year
    @return returns a boolean indicating whether the given year as a parameter is a leap year or not
    */
   public boolean testLeapYear(int year)
   {
       if(year % 4 != 0)
           return false;
       if(year % 100 != 0)
           return true;
       if(year % 400 != 0)
           return false;
       return true;
       
           
       
   }
   
   /**
    this function tests whether or not the current Date object called in scope is a valid date or not
    according to the parameters of the project. We test whether or not the month give is between 1 and 12 etc and whether or not
    the given day is within the scope of that specific month. A basic year test of being at least greater than or equal to 0 is also included
    In addition, the testLeapYear() method is also called to test if February is sent in as a month.
    @return This returns a boolean confirming whether or not the date is a valid date or not
    */
   public boolean isValid()
   {
       if((month < 1 || month > 12))
           return false;
       if(year < 0)
           return false;
       if(((month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12) && (day < 1 || day > 31)))
           return false;
       if((month == 4 || month == 6 || month == 9 || month == 11) && (day < 1 || day > 30))
           return false;
       if(month == 2)//This is where we test if the month is February, and if it is, we make  the necessary calls to testLeapYear().
       {
           if(testLeapYear(year) == false)
           {
               if(day < 1 || day > 28)
                   return false;
           } else if(testLeapYear(year) == true)
           {
               if(day < 1 || day > 29)
                   return false;
           }
           
       }
       
       return true;
       
   }
   
   @Override
   
   /**
    simple toString method to return the Date in "mm/dd/yyyy" format
    @return returns a string so that it can be printed to console.
    */
   public String toString()
   {
       return(month + "/" + day + "/" + year);
       //use the format "month/day/year"
   }
   
   @Override
   /**
    Equals method which test to see if the given object parameter is equal to the Date object called in scope.
    Because an Object class is passed, we have to test to make sure the object is a Date object by using the instanceof call.
    If the object is a Date object, we can test if they are equal by seeing if the month, day, and year are exactly the same.
    @return returns a boolean indicating whether or not the two dates are equal.
    */
   public boolean equals(Object obj)
   {
       if(!(obj instanceof Date))// we need to test to see if obj is of type Date before we compare.
           return false;
       Date dateToCompare = (Date)obj;// if obj is of type Date, we type cast it to another variable so its data members can be accessed.
       if((month == dateToCompare.month) && (day == dateToCompare.day) && (year == dateToCompare.year))
           return true;
       else
           return false;
   }
   
   public static void main(String[] args) 
   {
       Date newDate1 = new Date("12/10/2005");
       System.out.println(newDate1);
       
       Date newDate2 = new Date("12/10/2005");
       System.out.println(newDate2);
       System.out.println(newDate1.equals(newDate2));
       Date newDate3 = new Date("11/10/2010");
       System.out.println(newDate2.equals(newDate3));
       
       Date newDate4 = new Date("13/10/2020");
       System.out.println(newDate4.isValid());
       
       Date newDate5 = new Date("12/32/2020");
       System.out.println(newDate5.isValid());
       
       Date newDate6 = new Date("12/10/2020");
       System.out.println(newDate6.isValid());
       
       Date newDate7 = new Date("2/30/2020");
       System.out.println(newDate7.isValid());
       
       Date newDate8 = new Date("2/29/2020");
       System.out.println(newDate8.isValid());
       
       Date newDate9 = new Date("2/29/2019");
       System.out.println(newDate9.isValid());
       
       
       
   }
}


