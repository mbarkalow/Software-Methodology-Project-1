
import java.util.Scanner;

/**
The ProjectManager class is the user interface class that is responsible for 
handling user input and outputting messages. Add, remove, print, and quit
operations are performed here.
@author  Mark and Jeremy Barkalow
*/
 
public class ProjectManager
{
   Scanner stdin = new Scanner(System.in);
   Team cs213 = new Team();
   
   /**
   This method is called from the Prog1 class. It sits in a while loop handling
   user input until a quit operation is requested. The switch is used to see what operation
   is requested by the user. A -> add operation, R -> remove operation, P -> print operation, 
   Q -> quit operation. The default in the switch is used when there is bad input. It checks
   to see if another line exists, if so, the scanner is sent to the next line.
   */
   public void run()
   {
      System.out.println("Let's start a new team!");
       
      boolean done = false;
      while ( !done )
      {
         String command = stdin.next();
         char input = command.charAt(0);
         switch ( input )  
         {   
            case 'A': 
                add();
                break; 
            case 'R':
                remove();
                break;
            case 'P':
                print();
                break;
            case 'Q': //The user wants to quit. This will print all of the members in the team and exit the application.
                print(); 
                System.out.println("The team is ready to go!");
                done = true;
                break;
            default: 
                System.out.println("Command " + "'" + input + "'" + " is not supported!");
                if(stdin.hasNextLine())
                {
                	stdin.nextLine(); //if there is bad input, skip to the next line.
                }
                break;
         }  
      }
      //write java code before you terminate the program
   } //run()
   
   /**
   This method is responsible for adding a TeamMember to the team. It checks
   that the date given is valid and that the TeamMember does not already exist.
   Corresponding outputs are printed if the operation was successful or not.
   */
   private void add()
   {
        String name = stdin.next();
        String inputtedDate = stdin.next();
        Date date = new Date(inputtedDate);
        
        if(!(date.isValid())) //if the date is not valid, print message.
        {
            System.out.println(inputtedDate + " is not a valid date!");
        }
        else //if the date is valid, check if the TeamMember is already in the team. If not, add to the team.
        {
            TeamMember member = new TeamMember(name, date);
            if(cs213.contains(member))
            {
                System.out.println(name + " " + inputtedDate + " is already in the team.");
            }
            else
            {
                cs213.add(member);
                System.out.println(name + " " + inputtedDate + " has joined the team.");
            }
        }
   }
   
   /**
   This method removes a TeamMember from the team. It first checks to make sure
   that the date is valid. If the date is not valid, it outputs an error message.
   If the date is valid, it removes the TeamMember and outputs a message letting
   the user know.
   */
   private void remove()
   {
        String name = stdin.next();
        String inputtedDate = stdin.next();
        Date date = new Date(inputtedDate);
        if(!(date.isValid())) //if the date is not valid, print error message.
        {
            System.out.println(inputtedDate + " is not a valid date!");
        }
        else //if the date is valid, check if the TeamMember exists. If so, remove from the team.
        {
            TeamMember member = new TeamMember(name, date);
            if(cs213.remove(member))
            {
                System.out.println(name + " " + inputtedDate + " has left the team.");
            }
            else
            {
                System.out.println(name + " " + inputtedDate + " is not a team member.");
            }
        }
   }
   
   /**
   This method prints all of the members in a team. It first checks to make sure
   that the team is not empty. If it is empty, it will print a message letting the user know.
   If it is not empty, all of the members will be output.
   */
   private void print()
   {
       if(cs213.isEmpty())
       {
           System.out.println("We have 0 team members!");
       }
       else
       {
           System.out.println("We have the following members: ");
           cs213.print();
           System.out.println("-- end of the list --");
       }
   }  
}
